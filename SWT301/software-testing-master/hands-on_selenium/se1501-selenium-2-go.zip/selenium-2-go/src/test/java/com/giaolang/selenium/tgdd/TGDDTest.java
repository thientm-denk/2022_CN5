/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.giaolang.selenium.tgdd;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

/**
 *
 * @author giao.lang
 */
public class TGDDTest {
    
    private static WebDriver myBrowser;
    private static String driverPath;
        
    @BeforeAll
    public static void setUpClass() throws InterruptedException {
        //mở trình duyệt
        driverPath = "chromedriver.exe";
        System.setProperty("webdriver.chrome.driver", driverPath);
        ChromeOptions opt = new ChromeOptions();
        opt.addArguments("--incognito");
        opt.addArguments("--lang=vi");
        
        myBrowser = new ChromeDriver(opt);
        myBrowser.manage().window().maximize();
        
        myBrowser.get("https://thegioididong.com");
        Thread.sleep(3000);
        
        //vi diệu bắt đầu, tắt nút Location cái đã
        
        WebElement locationPopupE = myBrowser.findElement(By.xpath("//*[@id=\"lc_pop--sugg\"]/div/div[2]/a[2]"));        
        locationPopupE.click();
    }
    
    @AfterAll
    public static void tearDownClass() {
        //myBrowser.quit();
    }
    
    
    @Test
    //Test case #???
    //Steps:
    //...
    public void verifyPhonePriceGivenAPhoneReturnsTheSamePriceBothInBriefAndDetailsPage() throws InterruptedException {
        WebElement searchBoxE = myBrowser.findElement(By.id("skw"));        
        searchBoxE.sendKeys("iphone 13");
        Thread.sleep(3000);
        searchBoxE.submit();
        
        //tìm thẻ chứa điện thoại đầu tiên
        WebElement phoneBriefE = myBrowser.findElement(By.xpath("//aside[@class='left_search']//li[6]//a"));        
        //giá của điện thoại lại nằm trong thẻ a, con thẻ li
        //in ra text trong thẻ a, qua hàm getText()
        String phoneInfo = phoneBriefE.getText();
        System.out.println("Price in brief: " + phoneInfo);
        
        searchBoxE.sendKeys("iphone 13");
                
    }
    
}
