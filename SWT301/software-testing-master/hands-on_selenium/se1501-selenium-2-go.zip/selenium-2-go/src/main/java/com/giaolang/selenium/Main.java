/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.giaolang.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

/**
 *
 * @author giao.lang
 */
public class Main {
    
    public static void main(String[] args) throws InterruptedException {
        //testSearchFunctionGivenAKeywordReturnsHyperlinks();
        //Integer nam = 2001;
        testBankLoginGivenAValidAccountReturnsWelcomeMessage();
    }
    
    //Test case #1: Check the Google search function with a predefined keyword
    //Preconditions: keyword to search: Trò chơi con mực
    //Steps: 
    //   1. Open a certain browswer, e.g. Chrome
    //   2. Type url: https://google.com
    //   3. Type keyword: Trò chơi con mực in the search box
    //   4. Hit enter
    //Expected result:
    //A list of hyperlinks with "Trò chơi con mực" included in each hyperlink'
    //description
    //TEST AUTOMATION BEGINS    
    public static void testSearchFunctionGivenAKeywordReturnsHyperlinks() throws InterruptedException {
        
        //chỉ ra tên và nơi nằm của driver điều khiển Chrome vật lí
        String driverPath = "chromedriver.exe";
        //mặc định code sẽ đi tìm .exe này ở thư mục app/code/dự án
        //giả sử bạn để .exe ở ổ D:\SWT301\Hands-on\selenium-2-go\chromedriver.exe
        //String driverPath1 = "D:\\SWT301\\Hands-on\\selenium-2-go\\chromedriver.exe";
        
        //khai báo biến môi trường dành riêng cho máy ảo Java JVM
        //biến môi trường này dùng riêng cho Selenium
        System.setProperty("webdriver.chrome.driver", driverPath);
        //Selenium đã biết cách tìm .exe ở đâu rồi
        
        //bonus thêm, trước khi new() báo tao mún ẩn danh, options
        ChromeOptions opt = new ChromeOptions();
        opt.addArguments("--incognito");
        //opt.addArguments("--lang=en-GB"); //China: zh-cn, Vietnam: vi
                
        WebDriver myBrowser = new ChromeDriver(opt);  //instance/object xh
        //sau lệnh này, Chrome xh trước mặt mình, ko care Chrome đã có
        //Khai Cha new Con
        //kể từ lúc này về sau, myBrowser chính là object trình duyệt
        //mún sai khiến br, ta chấm gọi hàm, br sẽ làm theo!!!!!
        //mặc định mở 1/2 màn hình, bung full màn hình giùm
        myBrowser.manage().window().maximize();
        
        //trình duyệt hãy vào Google giùm tao 1 cái
        myBrowser.get("https://google.com");
        
        //tìm ô search qua xPath, CSS Selector, id, name, ....
        //1 tag ~~~ 1 object kiểu WebElement
        //WebElement searchBox = myBrowser.findElement(By.xpath("/html/body/div[1]/div[3]/form/div[1]/div[1]/div[1]/div/div[2]/input"));
        
        //WebElement searchBox = myBrowser.findElement(By.xpath("//input[@title='Tìm kiếm']"));
        WebElement searchBox = myBrowser.findElement(By.name("q"));
        
        searchBox.sendKeys("Trò chơi con mực"); //gõ từ khóa vào ô search
        
        Thread.sleep(2000);  //ngừng lại 2s 
        
        searchBox.submit(); //ô này nằm trong <form...> 
        
        //Thread.sleep(2000);  //ngừng lại 2s 
        //myBrowser.quit();  //tắt trình duyệt
    }
    //cào data từ site khác, crawler, bot đi cào

    
    //Test case #2: Check the login function of GuruBank...
    //...
    public static void testBankLoginGivenAValidAccountReturnsWelcomeMessage() throws InterruptedException {
        
        //chỉ ra tên và nơi nằm của driver điều khiển Chrome vật lí
        String driverPath = "chromedriver.exe";
        //mặc định code sẽ đi tìm .exe này ở thư mục app/code/dự án
        //giả sử bạn để .exe ở ổ D:\SWT301\Hands-on\selenium-2-go\chromedriver.exe
        //String driverPath1 = "D:\\SWT301\\Hands-on\\selenium-2-go\\chromedriver.exe";
        
        //khai báo biến môi trường dành riêng cho máy ảo Java JVM
        //biến môi trường này dùng riêng cho Selenium
        System.setProperty("webdriver.chrome.driver", driverPath);
        //Selenium đã biết cách tìm .exe ở đâu rồi
        
        //bonus thêm, trước khi new() báo tao mún ẩn danh, options
        ChromeOptions opt = new ChromeOptions();
        opt.addArguments("--incognito");
        //opt.addArguments("--lang=en-GB"); //China: zh-cn, Vietnam: vi
                
        WebDriver myBrowser = new ChromeDriver(opt);  //instance/object xh
        //sau lệnh này, Chrome xh trước mặt mình, ko care Chrome đã có
        //Khai Cha new Con
        //kể từ lúc này về sau, myBrowser chính là object trình duyệt
        //mún sai khiến br, ta chấm gọi hàm, br sẽ làm theo!!!!!
        //mặc định mở 1/2 màn hình, bung full màn hình giùm
        myBrowser.manage().window().maximize();
        
        //trình duyệt hãy vào Google giùm tao 1 cái
        myBrowser.get("https://www.demo.guru99.com/V4/index.php");
       
        WebElement username = myBrowser.findElement(By.cssSelector("input[name='uid']"));        
        username.sendKeys("mngr361652"); 
        
        WebElement pass = myBrowser.findElement(By.name("password"));        
        pass.sendKeys("ujYzEte"); 
        
        WebElement btnLogin = myBrowser.findElement(By.xpath("//input[@name='btnLogin']"));        
        btnLogin.submit();
                
        Thread.sleep(3000);  //ngừng lại 2s 
        
        
        //tìm câu msg Hello chào người dùng
        WebElement welcomeMsg = myBrowser.findElement(By.cssSelector("tr[class='heading3'] td"));        
        System.out.println("Welcome message is: " + welcomeMsg.getText());
                
       
        //Thread.sleep(2000);  //ngừng lại 2s 
        //myBrowser.quit();  //tắt trình duyệt
    }
    //cào data từ site khác, crawler, bot đi cào
}
